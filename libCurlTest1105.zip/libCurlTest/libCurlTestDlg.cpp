
// libCurlTestDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "libCurlTest.h"
#include "libCurlTestDlg.h"
#include "afxdialogex.h"
#include "LibCurlDemo.h"
#include "LockMutex.h"
#include "FtpCurl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
CInternetHttp  g_http;

// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// ClibCurlTestDlg �Ի���



ClibCurlTestDlg::ClibCurlTestDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(ClibCurlTestDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void ClibCurlTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_TIPPORT, m_sPortTip);
	DDX_Control(pDX, IDC_BUTTON_LISTEN, m_ButtonListen);
}

BEGIN_MESSAGE_MAP(ClibCurlTestDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_TESTFUN1, &ClibCurlTestDlg::OnBnClickedButtonTestfun1)
	ON_BN_CLICKED(IDC_BUTTON_TESTFUN2, &ClibCurlTestDlg::OnBnClickedButtonTestfun2)
	ON_BN_CLICKED(IDC_BUTTON_LISTEN, &ClibCurlTestDlg::OnBnClickedButtonListen)
	ON_BN_CLICKED(IDC_BUTTON_UNINIT, &ClibCurlTestDlg::OnBnClickedButtonUninit)
END_MESSAGE_MAP()


// ClibCurlTestDlg ��Ϣ��������

BOOL ClibCurlTestDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ  ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO:  �ڴ����Ӷ���ĳ�ʼ������
// 	m_hMutex = NULL;
// 	//��������
// 	if (NULL == m_hMutex)
// 	{
// 		CString strMutexName = _T("Sumszw_abc");
// 		m_hMutex = CreateMutex(NULL, FALSE, strMutexName);
// 
// 		if (NULL == m_hMutex)
// 		{
// 			return TRUE;
// 		}
// 	}
// 	CLocalMutex localLock(&m_hMutex); //��
// 	while (1)
// 	{
// 		Sleep(1);
// 	}


	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void ClibCurlTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ  ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void ClibCurlTestDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR ClibCurlTestDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void ClibCurlTestDlg::OnBnClickedButtonTestfun1()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	CLiburlDemo liburlDemo1;
	liburlDemo1.myApiTest();



// 	int iPort = 9986;
// 	ConnectKernel(m_Connection, iPort, GetData);

//	m_Connection.UnInit();
}


void ClibCurlTestDlg::OnBnClickedButtonTestfun2()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
// 	CLiburlDemo liburlDemo1;
// 	liburlDemo1.GetHtmlFromUrl("https://www.baidu.com");

// 	CURL *curldwn = NULL;
// 	curl_global_init(CURL_GLOBAL_ALL);
// 	curldwn = curl_easy_init();

	CFtpCurl _curl;
	_curl.download("ftp://103.25.23.14:40/�۴�ʦ�ͻ��˷������/ZhouDaShi_OnlineCount.csv", "C:\\Users\\Administrator\\Desktop\\�ճ����\\ZhouDaShi_OnlineCount.csv", 1, 3);
	//_curl.upload("ftp://192.168.1.195/haha.csv", "C:\\Users\\Administrator\\Desktop\\�ճ����\\ZhouDaShi_OnlineCount.csv", 1, 3);
}


#define BUFSIZE 41000
#define URLSIZE 1024

//��HTTP����URL�л�ȡHTTP�����
char* GetParamFromUrl(const char* strUrl)
{
	char url[URLSIZE] = { 0 };
	strcpy(url, strUrl);

	char* strAddr = strstr(url, "http://");//�ж���û��http://
	if (strAddr == NULL) {
		strAddr = strstr(url, "https://");//�ж���û��https://
		if (strAddr != NULL) {
			strAddr += 8;
		}
	}
	else {
		strAddr += 7;
	}

	if (strAddr == NULL) {
		strAddr = url;
	}
	int iLen = strlen(strAddr);
	char* strParam = (char*)malloc(iLen + 1);
	memset(strParam, 0, iLen + 1);
	int iPos = -1;
	for (int i = 0; i < iLen + 1; i++) {
		if (strAddr[i] == '/') {
			iPos = i;
			break;
		}
	}
	if (iPos == -1) {
		strcpy(strParam, "");;
	}
	else {
		strcpy(strParam, strAddr + iPos + 1);
	}
	return strParam;
}
//��HTTP����URL�л�ȡ������ַ����ַ���ߵ��ʮ����IP��ַ
char* GetHostAddrFromUrl(const char* strUrl)
{
	char url[URLSIZE] = { 0 };
	strcpy(url, strUrl);

	char* strAddr = strstr(url, "http://");//�ж���û��http://
	if (strAddr == NULL) {
		strAddr = strstr(url, "https://");//�ж���û��https://
		if (strAddr != NULL) {
			strAddr += 8;
		}
	}
	else {
		strAddr += 7;
	}

	if (strAddr == NULL) {
		strAddr = url;
	}
	int iLen = strlen(strAddr);
	char* strHostAddr = (char*)malloc(iLen + 1);
	memset(strHostAddr, 0, iLen + 1);
	for (int i = 0; i < iLen + 1; i++) {
		if (strAddr[i] == '/') {
			break;
		}
		else {
			strHostAddr[i] = strAddr[i];
		}
	}

	return strHostAddr;
}

//����HTTP��Ϣͷ
char* HttpHeadCreate(const char* strMethod, const char* strUrl, const char* strData)
{
// 	char* addr = "http://lordrobert.iask.in/notify?action=recharge_notify";
// 
// 
// 	char *host = "127.0.0.1";
// 	int port = 9986;
// 
// 
// 	char *pHttpPost = "POST %s HTTP/1.1\r\n"
// 		"Host: %s:%d\r\n"
// 		"Content-Type: text/plain\r\n"
// 		"Content-Length: %d\r\n\r\n"
// 		"%s";
// 
// 	//Post ������������ʽҪ���������ν��ա���һ������������д��
// 	char *msg = "{\"openid\": \"oG6_5wZTEUmVYF__n7TMgO1yWxFw\", \"RoomName\": \"���201\",\"TradeNO\": \"20160718025309674\",\"balanceMoney\": 50,\"MonneyCount\": 5,\"Time\": \"20160718025309\",\"TradeType\": 1,\"return_code\":\"SUCCESS\"}";
// 
// 
// 	//char* msg = "Inputs={\"WeiChartID\":\"oG6_5wZTEUmVYF__n7TMgO1yWxFw\"}";
// 
// 
// 	char strHttpPost[1024] = { 0 };
// 	sprintf_s(strHttpPost, pHttpPost, addr, host, port, strlen(msg), msg);


// 	POST / HTTP / 1.1
// 	Accept: */*
// 			 Host: 127.0.0.1
// 			 Cache-Control: no-cache
// 			 Connection: Keep-Alive
// 			 Content-Type: text/plain
// 			 Content-Length: 14
// 
// 			 wolegequyayaya
// 
// 
// 
// 	POST / HTTP / 1.1
// 	Accept: */*
// 			 Content-Type: application/x-www-form-urlencoded
// 			 Host: 127.0.0.1:9986
// 			 Cache-Control: no-store,no-cache
// 			 Pragma: no-cache
// 			 Content-Length: 4
// 			 Expect: 100-continue
// 			 Connection: Close

	char* strHost = GetHostAddrFromUrl(strUrl);
	char* strParam = GetParamFromUrl(strUrl);

	char* strHttpHead = (char*)malloc(BUFSIZE);
	memset(strHttpHead, 0, BUFSIZE);

	strcat(strHttpHead, strMethod);
	strcat(strHttpHead, " /");
	strcat(strHttpHead, strParam);
	free(strParam);
	strcat(strHttpHead, " HTTP/1.1\r\n");
// 	strcat(strHttpHead, "Accept: */*\r\n");
//  	strcat(strHttpHead, "Accept-Language: cn\r\n");
 	strcat(strHttpHead, "User-Agent: Mozilla/4.0\r\n");
	strcat(strHttpHead, "Host: ");
	strcat(strHttpHead, strHost);
	strcat(strHttpHead, "\r\n");
	strcat(strHttpHead, "Cache-Control: no-cache\r\n");
	strcat(strHttpHead, "Connection: Keep-Alive\r\n");
	if (0 == strcmp(strMethod, "POST"))
	{
		char len[8] = { 0 };
		unsigned uLen = strlen(strData);
		sprintf(len, "%d", uLen);

//		strcat(strHttpHead, "Content-Type: application/x-www-form-urlencoded\r\n");
		strcat(strHttpHead, "Content-Type: text/plain\r\n");
		strcat(strHttpHead, "Content-Length: ");
		strcat(strHttpHead, len);
		strcat(strHttpHead, "\r\n\r\n");
		strcat(strHttpHead, strData);
	}
	strcat(strHttpHead, "\r\n\r\n");

	free(strHost);

	return strHttpHead;
}

DWORD GetData(TCHAR *Orgbuf, DWORD dwTotalLen)
{
	CString strData(Orgbuf);

//	char* strHttpHead = HttpHeadCreate("POST", "http://127.0.0.1", "wolegequyayaya");
//	string content = ""
	char* strHttpHead = "HTTP/1.1 200 OK\r\nServer: pengju\r\nContent-length:12\r\n\r\nHello World!\r\n\r\n";

// 	char* addr = "http://lordrobert.iask.in/notify?action=recharge_notify";
// 
// 
// 	char *host = "127.0.0.1";
// 	int port = 9986;
// 
// 
// 	char *pHttpPost = "POST %s HTTP/1.1\r\n"
// 		"Host: %s:%d\r\n"
// 		"Content-Type: text/plain\r\n"
// 		"Content-Length: %d\r\n\r\n"
// 		"%s";
// 
// 	//Post ������������ʽҪ���������ν��ա���һ������������д��
// 	char *msg = "{\"openid\": \"oG6_5wZTEUmVYF__n7TMgO1yWxFw\", \"RoomName\": \"���201\",\"TradeNO\": \"20160718025309674\",\"balanceMoney\": 50,\"MonneyCount\": 5,\"Time\": \"20160718025309\",\"TradeType\": 1,\"return_code\":\"SUCCESS\"}";
// 
// 
// 	//char* msg = "Inputs={\"WeiChartID\":\"oG6_5wZTEUmVYF__n7TMgO1yWxFw\"}";
// 
// 
// 	char strHttpPost[1024] = { 0 };
// 	sprintf_s(strHttpPost, pHttpPost, addr, host, port, strlen(msg), msg);
// 
	int ret = send(g_ClientSocket, (char *)strHttpHead, strlen(strHttpHead), 0);
//	int ret = send(g_ClientSocket, (char *)strHttpHead, strlen(strHttpHead) + 1, 0);

//	free(strHttpHead);
	return 0;
//	send(iSockFd, (char *)strHttpHead, strlen(strHttpHead) + 1, 0);


	CString  strPostAddr = _T("http://127.0.0.1:9986");
	CString strPostUrlEncodeData = strData;
	CString strResponseText = _T("");

	strPostUrlEncodeData += _T("_OK");
	int iRet = g_http.HttpPost(strPostAddr, strPostUrlEncodeData, strResponseText);



	return 0;
}
void ClibCurlTestDlg::ConnectKernel(CCommServer &Comserver, int &iPort, pfnDataHandler fn)
{
	int i = 0;
	while (i < 10)
	{
		if (Comserver.Init(iPort, fn) == 0)
		{
			CString sPort;
			sPort.Format(_T("�����˿�Ϊ��%d"), iPort);
			m_sPortTip.SetWindowTextW(sPort);


			break;
		}

		iPort = GetTickCount() % (65535 - 10000) + 10000; //����˿�
		i++;
	}
}


void ClibCurlTestDlg::OnBnClickedButtonListen()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	m_ButtonListen.EnableWindow(FALSE);
	int iPort = 9986;
	ConnectKernel(m_Connection, iPort, GetData);

}


void ClibCurlTestDlg::OnBnClickedButtonUninit()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	m_Connection.UnInit();
	m_sPortTip.SetWindowTextW(_T(""));
	m_ButtonListen.EnableWindow(TRUE);
}
