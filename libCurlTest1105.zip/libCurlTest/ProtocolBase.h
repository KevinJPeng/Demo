#ifndef _PROTOCOLBASE_H_
#define _PROTOCOLBASE_H_
#include "curl.h"
using namespace std;

typedef struct _loginDataInfo
{

}loginDataInfo, *pLoginDataInfo;

class CProtocolBase
{
public:
	CProtocolBase();
	virtual ~CProtocolBase();

	virtual int upload(const char * remotepath, const char * localpath, long timeout, long tries);
	virtual int download(const char * remotepath, const char * localpath, long timeout, long tries);

protected:
private:
};
#endif