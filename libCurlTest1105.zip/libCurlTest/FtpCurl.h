#ifndef _FTPCURL_H_
#define _FTPCURL_H_
#include "ProtocolBase.h"

class CFtpCurl : public CProtocolBase
{
public:
	CFtpCurl();
	~CFtpCurl();

	virtual int upload(const char * remotepath, const char * localpath, long timeout, long tries);
	virtual int download(const char * remotepath, const char * localpath, long timeout, long tries);

	static size_t getcontentlengthfunc(void * _ptr, size_t _size, size_t _nmemb, void * _stream);
	static size_t discardfunc(void * _ptr, size_t _size, size_t _nmemb, void * _stream);
	static size_t writefunc(void * _ptr, size_t _size, size_t _nmemb, void * _stream);
	static size_t readfunc(void * _ptr, size_t _size, size_t _nmemb, void * _stream);

protected:
private:
	CURL* m_curlHandle;
};
#endif