
// libCurlTestDlg.h : ͷ�ļ�
//

#pragma once
#include "Commserver.h"
#include "InternetHttp.h"
#include "afxwin.h"

// ClibCurlTestDlg �Ի���
class ClibCurlTestDlg : public CDialogEx
{
// ����
public:
	ClibCurlTestDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_LIBCURLTEST_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonTestfun1();
	afx_msg void OnBnClickedButtonTestfun2();

	//�����ں�
	void ConnectKernel(CCommServer &Comserver, int &iPort, pfnDataHandler fn);

	//�������ͨѶ begin--
	CCommServer m_Connection;


	afx_msg void OnBnClickedButtonListen();
	afx_msg void OnBnClickedButtonUninit();
	CStatic m_sPortTip;
	CButton m_ButtonListen;


	HANDLE  m_hMutex;

};




extern CInternetHttp  g_http;

DWORD GetData(TCHAR *Orgbuf, DWORD dwTotalLen);
char* HttpHeadCreate(const char* strMethod, const char* strUrl, const char* strData);
char* GetParamFromUrl(const char* strUrl);
char* GetHostAddrFromUrl(const char* strUrl);
