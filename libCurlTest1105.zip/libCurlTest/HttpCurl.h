#ifndef _HTTPCURL_H_
#define _HTTPCURL_H_
#include "ProtocolBase.h"

class CHttpCurl : public CProtocolBase
{
public:
	CHttpCurl();
	~CHttpCurl();

	virtual int upload(CURL *curlhandle, const char * remotepath, const char * localpath, long timeout, long tries);
	virtual int download(CURL *curlhandle, const char * remotepath, const char * localpath, long timeout, long tries);

protected:
private:
};
#endif