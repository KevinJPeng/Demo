#include "stdafx.h"
#include "ProtocolBase.h"
#pragma comment (lib, "libcurl.lib" )

CProtocolBase::CProtocolBase()
{

}
CProtocolBase::~CProtocolBase()
{

}

int CProtocolBase::upload(const char * remotepath, const char * localpath, long timeout, long tries)
{
	return 0;
}
int CProtocolBase::download(const char * remotepath, const char * localpath, long timeout, long tries)
{
	return 0;
}