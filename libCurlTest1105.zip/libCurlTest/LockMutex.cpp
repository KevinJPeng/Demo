﻿#include "stdafx.h"
#include "LockMutex.h"



CLocalMutex::CLocalMutex(HANDLE* phMutex)
{
	m_hMutex = NULL;
	if (!phMutex)
	{
		return;
	}

	m_hMutex = phMutex;
	WaitForSingleObject(*m_hMutex, INFINITE);
}

CLocalMutex::~CLocalMutex()
{
	if (m_hMutex)
	{
		ReleaseMutex(*m_hMutex);
		m_hMutex = NULL;
	}
}