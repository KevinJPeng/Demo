#ifndef _LIBCURLDEMO_H_
#define _LIBCURLDEMO_H_

#include "curl.h"
#include "string"
using namespace std;
class CLiburlDemo
{
public:
	CLiburlDemo();
	~CLiburlDemo();

	void myApiTest();
	string GetHtmlFromUrl(const char* url);
	static size_t GetContent(char* buffer, size_t _size, size_t _nmemb, void* userdata);
	static size_t FuncCallBack(char* _data, size_t _size, size_t _nmemb, string* writedata);
protected:
private:
};
#endif