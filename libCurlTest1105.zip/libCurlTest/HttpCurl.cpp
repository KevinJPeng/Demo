#include "stdafx.h"
#include "HttpCurl.h"
#pragma comment (lib, "libcurl.lib" )

CHttpCurl::CHttpCurl()
{

}
CHttpCurl::~CHttpCurl()
{

}

int CHttpCurl::upload(CURL *curlhandle, const char * remotepath, const char * localpath, long timeout, long tries)
{
	return 0;
}
int CHttpCurl::download(CURL *curlhandle, const char * remotepath, const char * localpath, long timeout, long tries)
{
	return 0;
}
